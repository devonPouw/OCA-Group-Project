package com.kahooters.ocaquiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OcaquizApplicationTests {

	@Test
	void contextLoads() {
	}

}
